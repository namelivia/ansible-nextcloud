<?php declare(strict_types=1);

namespace OCA\Notes\Service;

use Exception;

class NotesFolderException extends Exception {
}
