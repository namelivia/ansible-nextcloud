<?php

$app = new OCA\Notes\Application();
$app->register();
