OC.L10N.register(
    "notes",
    {
    "Notes" : "筆記",
    "Error" : "錯誤",
    "New note" : "新筆記",
    "Settings" : "設定",
    "Today" : "今日",
    "Yesterday" : "明日",
    "Rename" : "重新命名",
    "Delete note" : "刪除筆記",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "編輯",
    "_%n word_::_%n words_" : ["%n 字"],
    "Android app" : "Android 應用程式",
    "iOS app" : "iOS 應用程式"
},
"nplurals=1; plural=0;");
