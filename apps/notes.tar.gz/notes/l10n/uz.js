OC.L10N.register(
    "notes",
    {
    "Notes" : "Eslatmalar",
    "Error" : "Xato",
    "New note" : "Yangi eslatma",
    "Settings" : "Sozlamalar",
    "Rename" : "Nomni o'zgartiring"
},
"nplurals=1; plural=0;");
