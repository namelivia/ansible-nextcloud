OC.L10N.register(
    "notes",
    {
    "Notes" : "บันทึกย่อ",
    "Error" : "ข้อผิดพลาด",
    "New note" : "สร้างบันทึกใหม่",
    "Settings" : "ตั้งค่า",
    "Today" : "วันนี้",
    "Yesterday" : "เมื่อวานนี้",
    "Rename" : "เปลี่ยนชื่อ",
    "Delete note" : "ลบบันทึกย่อ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "รายละเอียด",
    "Edit" : "แก้ไข",
    "_%n word_::_%n words_" : ["%n คำ"],
    "Android app" : "แอพฯ แอนดรอยด์",
    "iOS app" : "แอพฯ IOS"
},
"nplurals=1; plural=0;");
