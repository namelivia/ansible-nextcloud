OC.L10N.register(
    "notes",
    {
    "Notes" : "ئىزاھاتلار",
    "Error" : "خاتالىق",
    "Settings" : "تەڭشەكلەر",
    "Today" : "بۈگۈن",
    "Rename" : "ئات ئۆزگەرت",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "تەھرىر"
},
"nplurals=1; plural=0;");
