OC.L10N.register(
    "notes",
    {
    "Notes" : "සටහන්",
    "Error" : "දෝෂයක්",
    "Settings" : "සැකසුම්",
    "Today" : "අද",
    "Yesterday" : "ඊයේ",
    "Rename" : "නැවත නම් කරන්න",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "සකසන්න"
},
"nplurals=2; plural=(n != 1);");
