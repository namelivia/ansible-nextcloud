<?php
script('notes', 'notes');
style('notes', 'notes');
?>
