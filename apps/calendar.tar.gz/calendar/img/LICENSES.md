# Licenses

## briefcase.svg
- Created by: [Oriza Creative](https://thenounproject.com/orizacreativa)
- License: CC-BY
- Link: https://thenounproject.com/search/?q=briefcase&i=2834945

## eye.svg
- Created by: [David](https://thenounproject.com/kaxgyatso)
- License: CC-BY
- Link: https://thenounproject.com/search/?q=eye&i=428971

# invitees-no-response.svg
- Created by: [Alena](https://thenounproject.com/joyeyes)
- License: CC-BY
- Link: https://thenounproject.com/search/?q=question%20mark&i=1156193

## repeat.svg
- Created by: [Brandy Bora](https://thenounproject.com/brandy.bora/)
- License: CC-BY
- Link: https://thenounproject.com/search/?q=repeat&i=1555394

## view-day.svg
- Created by: Google
- License: Apache License version 2.0
- Link: https://material.io/resources/icons/?search=view_&icon=view_day&style=baseline

## view-list.svg
- Created by: Google
- License: Apache License version 2.0
- Link: https://material.io/resources/icons/?search=view_&icon=view_list&style=baseline

## view-module.svg
- Created by: Google
- License: Apache License version 2.0
- Link: https://material.io/resources/icons/?search=view_&icon=view_module&style=baseline

## view-week.svg
- Created by: Google
- License: Apache License version 2.0
- Link: https://material.io/resources/icons/?search=view_&icon=view_week&style=baseline

## new-calendar.svg
- Created by: Austin Andrews
- License: Apache License version 2.0
- Link: https://materialdesignicons.com/icon/calendar-blank

## new-calendar-with-task-list.svg
- Created by: Google
- License: Apache License version 2.0
- Link: https://materialdesignicons.com/icon/calendar-check
