<?php
    script('tasks', 'tasks');
    style('tasks', 'tasks');
?>
