OC.L10N.register(
    "tasks",
    {
    "Important" : "වැදගත්",
    "Today" : "අද",
    "Week" : "සතිය",
    "All" : "සියල්ල",
    "Tasks" : "කාර්යය",
    "can edit" : "සංස්කරණය කළ හැක",
    "Cancel" : "එපා",
    "Save" : "සුරකින්න",
    "Edit" : "සකසන්න",
    "Download" : "බාන්න",
    "Delete" : "මකා දමන්න",
    "Unshare" : "නොබෙදු"
},
"nplurals=2; plural=(n != 1);");
