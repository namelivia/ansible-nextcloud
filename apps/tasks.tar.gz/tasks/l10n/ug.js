OC.L10N.register(
    "tasks",
    {
    "Important" : "مۇھىم",
    "Today" : "بۈگۈن",
    "Week" : "ھەپتە",
    "All" : "ھەممىسى",
    "Tasks" : "ۋەزىپەلەر",
    "Cancel" : "ۋاز كەچ",
    "Save" : "ساقلا",
    "Edit" : "تەھرىر",
    "Download" : "چۈشۈر",
    "Delete" : "ئۆچۈر",
    "Unshare" : "ھەمبەھىرلىمە"
},
"nplurals=1; plural=0;");
