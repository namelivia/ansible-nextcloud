OC.L10N.register(
    "tasks",
    {
    "Important" : "اہم",
    "Today" : "آج",
    "Week" : "ہفتہ",
    "Tasks" : "کام",
    "can edit" : "تبدیل کر سکے ھیں",
    "Cancel" : "منسوخ کریں",
    "Save" : "حفظ",
    "Edit" : "تدوین کریں",
    "Download" : "ڈاؤن لوڈ",
    "Delete" : "حذف کریں",
    "Unshare" : "شئیرنگ ختم کریں"
},
"nplurals=2; plural=(n != 1);");
