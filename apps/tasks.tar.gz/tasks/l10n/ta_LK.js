OC.L10N.register(
    "tasks",
    {
    "Important" : "முக்கியமான ",
    "Today" : "இன்று",
    "Week" : "வாரம்",
    "All" : "எல்லாம்",
    "Tasks" : "கடமைகள்",
    "can edit" : "தொகுக்க முடியும்",
    "Cancel" : "இரத்து செய்க",
    "Save" : "சேமிக்க ",
    "Edit" : "தொகுக்க",
    "Download" : "பதிவிறக்குக",
    "Delete" : "நீக்குக",
    "Unshare" : "பகிரப்படாதது"
},
"nplurals=2; plural=(n != 1);");
