OC.L10N.register(
    "tasks",
    {
    "Today" : "Այսօր",
    "Week" : "Շաբաթ",
    "Current" : "Ընթացիկ",
    "Completed" : "Ավարտվեց",
    "Share with users or groups" : "Կիսվել օգտատերերի կամ խմբերի հետ",
    "can edit" : "կարող է խմբագրել",
    "Cancel" : "Չեղարկել",
    "Save" : "Պահել",
    "Edit" : "Խմբագրել",
    "Download" : "Ներբեռնել",
    "Delete" : "Ջնջել",
    "Unshare" : "Չկիսվել"
},
"nplurals=2; plural=(n != 1);");
