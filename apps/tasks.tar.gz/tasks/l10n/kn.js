OC.L10N.register(
    "tasks",
    {
    "Today" : "Today",
    "All" : "﻿ಎಲ್ಲಾ",
    "can edit" : "﻿ಸಂಪಾದಿಸಬಹುದು",
    "Cancel" : "﻿ರದ್ದು",
    "Save" : "﻿ಉಳಿಸಿ",
    "Edit" : "ಸಂಪಾದಿಸು",
    "Download" : "ಪ್ರತಿಯನ್ನು ಸ್ಥಳೀಯವಾಗಿ ಉಳಿಸಿಕೊಳ್ಳಿ",
    "Delete" : "﻿ಅಳಿಸಿ",
    "Unshare" : "ಹಂಚಿಕೆಯನ್ನು ಹಿಂತೆಗೆ"
},
"nplurals=2; plural=(n > 1);");
