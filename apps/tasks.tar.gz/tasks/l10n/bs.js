OC.L10N.register(
    "tasks",
    {
    "Important" : "Važno",
    "Today" : "Danas",
    "Week" : "Sedmica",
    "All" : "Svi",
    "Current" : "Trenutno",
    "Completed" : "Zavrženo",
    "Tasks" : "Zadaci",
    "can edit" : "mogu mijenjati",
    "Cancel" : "Odustani",
    "Save" : "Spremi",
    "Edit" : "Izmjeni",
    "Download" : "Preuzmi",
    "Delete" : "Obriši",
    "Unshare" : "Prestani  dijeliti",
    "Tomorrow" : "Sutra"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
