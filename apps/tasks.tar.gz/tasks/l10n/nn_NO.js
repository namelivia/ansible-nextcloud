OC.L10N.register(
    "tasks",
    {
    "Important" : "Viktig",
    "Today" : "I dag",
    "Week" : "Veke",
    "All" : "Alle",
    "Tasks" : "Oppgåver",
    "can edit" : "kan endra",
    "Cancel" : "Avbryt",
    "Save" : "Lagra",
    "Edit" : "Endra",
    "Download" : "Last ned",
    "Delete" : "Slett",
    "Unshare" : "Fjern deling",
    "Last modified" : "Siste endra",
    "When shared show full event" : "Når delt, vis heile hendinga",
    "When shared show only busy" : "Når delt, vis berre oppteken",
    "When shared hide this event" : "Når delt, gøym denne hendinga"
},
"nplurals=2; plural=(n != 1);");
