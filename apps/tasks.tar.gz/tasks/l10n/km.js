OC.L10N.register(
    "tasks",
    {
    "Important" : "សំខាន់",
    "Today" : "ថ្ងៃ​នេះ",
    "Week" : "សប្ដាហ៍",
    "All" : "ទាំងអស់",
    "Tasks" : "ភារកិច្ច",
    "can edit" : "អាច​កែប្រែ",
    "Cancel" : "បោះបង់",
    "Save" : "រក្សាទុក",
    "Edit" : "កែប្រែ",
    "Download" : "ទាញយក",
    "Delete" : "លុប",
    "Unshare" : "លែង​ចែក​រំលែក"
},
"nplurals=1; plural=0;");
