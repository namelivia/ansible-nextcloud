OC.L10N.register(
    "tasks",
    {
    "Today" : "Hari ini",
    "Week" : "Minggu",
    "can edit" : "boleh mengubah",
    "Cancel" : "Batal",
    "Save" : "Simpan",
    "Edit" : "Sunting",
    "Download" : "Muat turun",
    "Delete" : "Padam"
},
"nplurals=1; plural=0;");
