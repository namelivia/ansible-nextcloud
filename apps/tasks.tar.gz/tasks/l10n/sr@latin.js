OC.L10N.register(
    "tasks",
    {
    "Today" : "Today",
    "Current" : "Tekuće",
    "Completed" : "Završeno",
    "can edit" : "može da menja",
    "Cancel" : "Cancel",
    "Save" : "Save",
    "Edit" : "Uredi",
    "Download" : "Preuzmi",
    "Delete" : "Delete",
    "Unshare" : "Ukini deljenje",
    "Due date" : "Rok"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
